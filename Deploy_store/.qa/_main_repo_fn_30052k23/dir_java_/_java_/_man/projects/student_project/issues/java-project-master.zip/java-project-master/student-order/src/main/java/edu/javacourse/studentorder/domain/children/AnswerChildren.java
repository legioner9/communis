package edu.javacourse.studentorder.domain.children;

public class AnswerChildren
{
}
