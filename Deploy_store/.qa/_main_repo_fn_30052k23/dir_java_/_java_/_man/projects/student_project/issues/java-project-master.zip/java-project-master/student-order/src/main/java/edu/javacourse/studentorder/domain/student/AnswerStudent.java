package edu.javacourse.studentorder.domain.student;

public class AnswerStudent
{
}
