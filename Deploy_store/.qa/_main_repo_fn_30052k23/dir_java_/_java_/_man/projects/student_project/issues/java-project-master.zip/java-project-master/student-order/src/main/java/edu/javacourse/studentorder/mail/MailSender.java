package edu.javacourse.studentorder.mail;

import edu.javacourse.studentorder.domain.StudentOrder;

public class MailSender
{
    public void sendMail(StudentOrder so) {
        System.out.println("Почта отправлена");
    }
}
