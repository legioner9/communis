package edu.javacourse.studentorder.domain.wedding;

public class AnswerWedding
{
}
