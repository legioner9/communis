var utils = {
    checkValue: function(val){
        return val != undefined && val != null && val != '';
    }
};
