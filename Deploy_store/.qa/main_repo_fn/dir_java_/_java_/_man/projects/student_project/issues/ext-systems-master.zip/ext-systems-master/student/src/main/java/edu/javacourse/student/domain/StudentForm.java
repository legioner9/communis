package edu.javacourse.student.domain;

public enum StudentForm
{
    DAY, EVENING, REMOTE
}
