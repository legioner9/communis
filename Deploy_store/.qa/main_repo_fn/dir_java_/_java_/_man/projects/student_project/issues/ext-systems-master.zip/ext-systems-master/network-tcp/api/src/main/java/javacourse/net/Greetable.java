package javacourse.net;

public abstract class Greetable
{
    public abstract String buildResponse(String userName);
}
