package com.max.soap;

public class SoapServiceImpl implements SoapService {
    public void printMessage(String s) {
        System.out.println(s);
    }
}
