package com.max

fun main(args: Array<String>) {
    var user = User("Max", 22)
}

class User(name:String, age: Int)