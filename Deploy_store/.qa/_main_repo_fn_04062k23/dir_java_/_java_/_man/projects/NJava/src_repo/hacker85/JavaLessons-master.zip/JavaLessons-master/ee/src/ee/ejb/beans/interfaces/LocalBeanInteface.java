package ee.ejb.beans.interfaces;

public interface LocalBeanInteface {
    String sayHello();
}
