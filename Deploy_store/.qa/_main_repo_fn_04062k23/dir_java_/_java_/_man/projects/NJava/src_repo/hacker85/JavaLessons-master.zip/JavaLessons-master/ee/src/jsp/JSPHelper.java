package jsp;

public class JSPHelper {
    public static int minux(int a, int b) {
        return a - b;
    }
}
