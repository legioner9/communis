package badpractice;

public class UserFactory {
    User getUser() {
        return new User();
    }
}
