package ee.jaxws.container;

import javax.jws.WebService;

@WebService
public interface ContainerService {
    String sayHello();
}
