package badpractice;

public class User {
    void exec() {
    }
    static String getInfo() {
        return "info";
    }
}
