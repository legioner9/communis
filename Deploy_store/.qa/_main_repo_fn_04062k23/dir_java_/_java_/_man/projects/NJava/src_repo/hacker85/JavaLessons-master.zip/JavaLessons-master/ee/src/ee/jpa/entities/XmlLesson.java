package ee.jpa.entities;

public class XmlLesson {
    int id;
    String name;
}
