import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(value = {CalculatorTest.class, CalculatorTest.class})
public class SuitExample {
}
