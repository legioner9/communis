package com.max.interfaces;

public interface Repo {
    void createTable();
}
