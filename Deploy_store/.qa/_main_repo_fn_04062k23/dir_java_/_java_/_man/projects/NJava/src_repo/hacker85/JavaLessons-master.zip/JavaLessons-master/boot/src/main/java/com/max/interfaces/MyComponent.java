package com.max.interfaces;

public interface MyComponent {
    void print();
}
