package com.max.web.repo;

import com.max.web.entities.User;

//@Repository
//@Transactional
public class UserRepository2 implements MyRepo {
//    @PersistenceContext
//    EntityManager entityManager;
    public void saveUser(User user) {
//        entityManager.persist(user);
    }
}
