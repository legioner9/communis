package com.max.web.config;

//@Configuration
//@ComponentScan(basePackages={"com.max.web"})
public class RootConfig {
}
