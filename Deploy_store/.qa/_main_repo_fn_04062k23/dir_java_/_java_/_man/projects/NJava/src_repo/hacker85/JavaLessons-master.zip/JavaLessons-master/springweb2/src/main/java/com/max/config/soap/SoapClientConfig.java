package com.max.config.soap;

//@Configuration
public class SoapClientConfig {
//    @Bean
//    JaxWsPortProxyFactoryBean portProxyFactoryBean() throws MalformedURLException {
//        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
//        bean.setWsdlDocumentUrl(new URL("http://localhost:8889/SoapService?wsdl"));
//        bean.setServiceName("SoapService");
//        bean.setServiceInterface(SoapService.class);
//        bean.setPortName("SoapServiceEndpointPort");
//        bean.setNamespaceUri("http://soap.max.com/");
//        return bean;
//    }
}
