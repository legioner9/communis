package com.max.web.config;

//@Configuration
//@Import(HiberConfig.class)
//@Import(JpaConfig.class)
public class DbConfig {
//    @Bean
//    public DataSource dataSource() {
//        DriverManagerDataSource ds = new DriverManagerDataSource();
//        ds.setDriverClassName("com.mysql.jdbc.Driver");
//        ds.setUrl("jdbc:mysql://localhost:3306/Lessons");
//        ds.setUsername("root");
//        ds.setPassword("1");
//        return ds;
//    }
//    @Bean
//    public DataSource dataSource() {
//        DriverManagerDataSource ds = new DriverManagerDataSource();
//        ds.setDriverClassName("org.h2.Driver");
//        ds.setUrl("jdbc:h2:~/test");
//        ds.setUsername("sa");
//        ds.setPassword("");
//        return ds;
//    }
//    @Bean
//    public JndiObjectFactoryBean dataSource() {
//        JndiObjectFactoryBean dataSource = new JndiObjectFactoryBean();
//        dataSource.setJndiName("jdbc/testDB");
//        dataSource.setResourceRef(true);
//        dataSource.setProxyInterface(DataSource.class);
//        return dataSource;
//    }
//    @Bean
//    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
//        return new JdbcTemplate(dataSource);
//    }
}
