public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public double div(int a, int b) {
        return a/b;
    }
}