package com.max.web.repo;

import com.max.web.entities.User;

public interface MyRepo {
    void saveUser(User user);
}
