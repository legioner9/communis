package ee.ejb.beans.interfaces;

public interface RemoteBeanInterface {
    String sayRemoteHello();
}
