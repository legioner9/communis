package com.max.aop;

public class DefaultEncoreable implements Encoreable {
    public void performEncore() {
        System.out.println("encore");
    }
}
