package com.max.test.interfaces;

public interface Car {
    void drive();
}
