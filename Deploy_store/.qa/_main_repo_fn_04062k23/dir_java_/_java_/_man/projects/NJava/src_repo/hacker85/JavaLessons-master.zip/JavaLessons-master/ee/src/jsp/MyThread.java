package jsp;

public class MyThread implements Runnable {
    @Override
    public void run() {

    }
}
