package com.max.config.security;

public class SecurityWebInitializer {}// extends AbstractSecurityWebApplicationInitializer {}