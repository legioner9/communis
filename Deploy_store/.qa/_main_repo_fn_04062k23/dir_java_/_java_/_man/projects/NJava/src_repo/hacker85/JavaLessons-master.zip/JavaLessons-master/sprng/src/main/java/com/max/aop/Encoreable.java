package com.max.aop;

public interface Encoreable {
    void performEncore();
}
