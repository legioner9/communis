package com.max.config;

//@Configuration
////@ComponentScan("com.max.impl")
//@ComponentScan("com.max.mongo")
////@Import(HiberConfig.class)
////@Import(JpaConfig.class)
//@Import(MongoConfig.class)
public class DbConfig {
//    @Bean
//    public DataSource dataSource() {
//        DriverManagerDataSource ds = new DriverManagerDataSource();
//        ds.setDriverClassName("com.mysql.jdbc.Driver");
//        ds.setUrl("jdbc:mysql://localhost:3306/Lessons");
//        ds.setUsername("root");
//        ds.setPassword("1");
//        return ds;
//    }
//    @Bean
//    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
//        return new JdbcTemplate(dataSource);
//    }
//    @Bean
//    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(DataSource dataSource) {
//        return new NamedParameterJdbcTemplate(dataSource);
//    }
//    @Bean
//    public DataSource dataSource() {
//        DriverManagerDataSource ds = new DriverManagerDataSource();
//        ds.setDriverClassName("org.h2.Driver");
//        ds.setUrl("jdbc:h2:~/test");
//        ds.setUsername("sa");
//        ds.setPassword("");
//        return ds;
//    }
//    @Bean
//    public DataSource dataSource() {
//        return new EmbeddedDatabaseBuilder().
//                setType(EmbeddedDatabaseType.H2).addScript("classpath:myScript.sql").build();
//    }
//    @Bean
//    public BasicDataSource dataSource() {
//        BasicDataSource dataSource = new BasicDataSource();
//        dataSource.setDriverClassName("org.h2.Driver");
//        dataSource.setUrl("jdbc:h2:~/test");
//        dataSource.setUsername("sa");
//        dataSource.setPassword("");
//        dataSource.setInitialSize(5);
//        dataSource.setMaxActive(10);
//        return dataSource;
//    }
}
