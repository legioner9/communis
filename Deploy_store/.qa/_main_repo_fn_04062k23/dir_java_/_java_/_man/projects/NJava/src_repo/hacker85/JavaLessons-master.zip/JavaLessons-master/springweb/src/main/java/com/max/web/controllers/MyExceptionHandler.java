package com.max.web.controllers;

//@ControllerAdvice
public class MyExceptionHandler {
//    @ExceptionHandler(ExceptionController.UserNotFoundException.class)
//    @ResponseBody
//    public String duplicateSpittleHandler() {
//        return "some error";
//    }
}
