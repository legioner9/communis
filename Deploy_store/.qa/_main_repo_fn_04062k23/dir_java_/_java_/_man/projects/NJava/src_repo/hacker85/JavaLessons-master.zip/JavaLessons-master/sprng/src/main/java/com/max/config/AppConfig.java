package com.max.config;

//@Configuration
public class AppConfig {
//    @Bean
//    public Car getCar1() {
//        Toyota car = new Toyota();
//        car.setRadio(bestFm());
//        return car;
//    }
//
//    @Bean
//    public Car getCar2() {
//        Ferrary car = new Ferrary();
//        car.setRadio(bestFm());
//        return car;
//    }

//    @Bean
//    public Radio bestFm() {
//        return new BestFm();
//    }
}
