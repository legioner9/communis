package com.max.web.config;

//@Configuration
//@EnableTransactionManagement
//@EnableJpaRepositories("com.max.web")
public class JpaConfig {
//    @Bean
//    public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(DataSource dataSource, JpaVendorAdapter jpaVendorAdapter) {
//        LocalContainerEntityManagerFactoryBean bean = new LocalContainerEntityManagerFactoryBean();
//        bean.setDataSource(dataSource);
//        bean.setJpaVendorAdapter(jpaVendorAdapter);
//        bean.setPackagesToScan("com.max.web.entities");
//        bean.setPersistenceUnitName("localJpa");
//        return bean;
//    }
//    @Bean
//    public JpaTransactionManager txManager() {
//        return new JpaTransactionManager();
//    }
//    @Bean
//    public JpaVendorAdapter jpaVendorAdapter() {
//        HibernateJpaVendorAdapter adapter = new HibernateJpaVendorAdapter();
//        adapter.setDatabase(Database.MYSQL);
//        adapter.setShowSql(true);
//        adapter.setGenerateDdl(true);
//        adapter.setDatabasePlatform("org.hibernate.dialect.MySQL5Dialect");
//        return adapter;
//    }
}
