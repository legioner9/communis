package com.max.config;

//@Configuration
//@ComponentScan
//@Import(Config2.class)
//@ImportResource("classpath:config2.xml")
//@PropertySource("classpath:my.properties")
public class Config {
//    @Autowired
//    Environment env;
//    @Bean
//    public Car getToyota(@MyRadio Radio radio) {
//        return new Toyota(radio, env.getProperty("name"));
//    }
}
