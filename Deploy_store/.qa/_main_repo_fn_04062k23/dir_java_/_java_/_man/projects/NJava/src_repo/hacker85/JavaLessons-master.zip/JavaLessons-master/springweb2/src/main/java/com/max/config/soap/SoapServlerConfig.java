package com.max.config.soap;

//@Configuration
public class SoapServlerConfig {
//    @Bean
//    SoapService soapService() {
//        return new SoapServiceImpl();
//    }
//    @Bean
//    SimpleJaxWsServiceExporter exporter() {
//        SimpleJaxWsServiceExporter exporter = new SimpleJaxWsServiceExporter();
//        exporter.setBaseAddress("http://localhost:8889/");
//        return exporter;
//    }
}
