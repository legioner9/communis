package com.max.config;

//@Configuration
public class Config2 {
//    @Bean
////    @Profile("default")
//    @Primary
//    @MyRadio
//    public Radio getRadio() {
//        return new BestFm();
//    }
//    @Bean
//    @Profile("dev")
//    @Conditional(MyCondition.class)
//    @Primary
//    public Radio getWorstFm() {
//        return new WorstFm();
//    }
}
