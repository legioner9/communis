package com.max.web.repo;

public interface Repo {
    User getUser();
}
