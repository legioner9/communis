package enums;

public enum  Days {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY
}
