package com.max.aop;

public interface Repo {
    void getInfo();
    void printName(String name);
}
