package com.max
fun main(args: Array<String>) {

}
fun add(a: Int, b: Int) = a + b;