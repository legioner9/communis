package com.max
fun main(args: Array<String>) {
    var a: Int
    var b: String
    var c = 5
}
