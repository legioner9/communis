package com.max.config;

//@Configuration
public class AmqpConfig {
//    @Bean
//    public ConnectionFactory connectionFactory() {
//        return new CachingConnectionFactory("localhost");
//    }
//    @Bean
//    public RabbitTemplate rabbitTemplate() {
//        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory());
//        rabbitTemplate.setQueue("myqueue");
//        return rabbitTemplate;
//    }
//    @Bean
//    public Queue myQueue() {
//        return new Queue("myqueue");
//    }
}
