package com.max.web.controllers;

//@Controller
public class ExceptionController {
//    @GetMapping("exception")
//    public void getException() {
////        throw new RuntimeException("some error");
//        throw new UserNotFoundException();
//    }
////    @ExceptionHandler(UserNotFoundException.class)
////    @ResponseBody
////    public String handleDuplicateSpittle() {
////        return "some error";
////    }
//    @ResponseStatus(value= HttpStatus.NOT_FOUND, reason="User Not Found")
//    public class UserNotFoundException extends RuntimeException {}
}
