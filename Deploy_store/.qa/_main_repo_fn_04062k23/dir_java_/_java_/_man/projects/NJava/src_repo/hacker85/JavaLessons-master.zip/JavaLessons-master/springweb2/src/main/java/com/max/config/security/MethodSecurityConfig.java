package com.max.config.security;

//@Configuration
//@EnableGlobalMethodSecurity(securedEnabled=true, jsr250Enabled=true, prePostEnabled = true)
public class MethodSecurityConfig {}// extends GlobalMethodSecurityConfiguration {}
