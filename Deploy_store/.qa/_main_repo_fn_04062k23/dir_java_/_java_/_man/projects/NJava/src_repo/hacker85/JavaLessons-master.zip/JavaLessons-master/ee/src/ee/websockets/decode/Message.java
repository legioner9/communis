package ee.websockets.decode;

public class Message {
    String s;

    public Message(String s) {
        this.s = s;
    }
}
